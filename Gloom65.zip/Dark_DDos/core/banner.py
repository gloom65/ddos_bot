banner = '+---------------+ \n|   Gloom65   |  \n|  Version 1.1  |  \n|   telegram: @gloom65   | \n+---------------+'

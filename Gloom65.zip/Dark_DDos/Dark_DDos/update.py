import os
import sys
os.system("rm -rf Dark_DDos; git clone https://github.com/DarkGa/Dark_DDos; rm -rf update.py")

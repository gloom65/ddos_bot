banner = '+---------------+ \n|   Dark_DDos   |  \n|  Version 1.1  |  \n|   DarkGamer   | \n+---------------+'
